# Garde les WebView JavaScript interfaces si on en ajoutait un jour
-keepclassmembers class fr.tibo.son.** {
   public *;
}
-keepattributes JavascriptInterface
